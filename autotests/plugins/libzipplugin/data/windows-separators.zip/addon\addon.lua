content of addon/addon.lua
