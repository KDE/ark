content of addon/lang/fr.lua
