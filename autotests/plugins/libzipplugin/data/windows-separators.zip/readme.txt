content of readme.txt
