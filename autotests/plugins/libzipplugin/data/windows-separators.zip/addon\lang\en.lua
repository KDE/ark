content of addon/lang/en.lua
