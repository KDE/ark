#define SOMETHING "something"
